##Tutorial:

Welcome to Bang. This is an Audio Game for Blind People with 3-Keys. Press 'space' to start.


We are going to go through a tutorial here. If you want to skip the tutorial, please press space.

You will wait to match your opponent until it has been found with a sound.  

In every round of the game, You will hear 5 pieces of drum beat sequences, each sequence has 5 beats. And there are only two beats: 
high key, 
and low key. 

After Every sequence, you have maximum 5 seconds of response slot to repeat what you heard. Pressing F represents the high key, and pressing J represents the low key. For example, If you hear. 
You should input F, J, J ,F ,J. After the fifth response slot, the game ends. You will win if you achieved more correct answers. Now, enjoy Bang! Good LUCK.