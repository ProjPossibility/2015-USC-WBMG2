$(function(){
	var status = 0;// 0 represent the intial status

	$(".tutorial").hide();
	$(".navi").hide();
	$("#nav span").hide();
	$("#instruction1").hide();
	$("#instruction2").hide();
	$("#instruction3").hide();
	$("#instruction4").hide();
	$("#instruction5").hide();
	$("#instruction6").hide();
	$("#instruction7").hide();
	$("#instruction8").hide();
	$("#instruction9").hide();
	$("#instruction10").hide();
	$("#instruction11").hide();
	$("#instruction12").hide();
	$("#instruction13").hide();
	$(".matching").hide();
	$(".tutorial input").hide();

	document.onkeypress=function(event){
		var e = event || window.event || arguments.callee.caller.arguments[0];

		if(e.which == 32){
			switch(status){

				case 0:
					status = 1;//1 status ready to run tutorial
					$(".mask").fadeOut("fast",function(){
						$(".navi").fadeIn("fast");
						$("#nav span").fadeIn(function(){
							$(".tutorial").fadeIn(function(){
								$("#instruction1").fadeIn();
								$("#tut").play();
								
								//3秒内没有 按空格就要播下一条音频
							});
						});
					});	
					break;
				case 1:
					status = 2;//2 status start matching
					$(".tutorial span").fadeOut(function(){
						$(".matching").fadeIn();
					});
					//跳转到matching界面
					break;

				//测试用
				case 2:
					status = 3;
					$(".matching").fadeOut(function(){
						$(".tutorial input").fadeIn();
						$(".tutorial input").focus();
					});	

			};				
		};
	};

	document.onkeydown=function(event){
		var e = event || window.event || arguments.callee.caller.arguments[0];

		switch(e.which){

			case 74:
				
				//$("#jcolor").show();
				break;

			case 70:
				alert("f down");
				//$("#fcolor").show();
				break;
		};

	};

});